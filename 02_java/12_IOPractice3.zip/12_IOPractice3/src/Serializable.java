
public interface Serializable {

}
