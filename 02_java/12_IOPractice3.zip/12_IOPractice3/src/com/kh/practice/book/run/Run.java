package com.kh.practice.book.run;

import com.kh.practice.book.view.BookMenu;

public class Run {
	public static void main(String[] args) {
		// BookMenu 클래스 객체 생성 후 mainMenu() 실행
		BookMenu bm = new BookMenu();
		bm.mainMenu();
	}
}






