package com.kh.practice.point.run;

import com.kh.practice.point.view.PointMenu;

public class Run {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		PointMenu pm = new PointMenu();
		
		pm.mainMenu();
		
//		System.out.print(Math.PI);
	}

}
